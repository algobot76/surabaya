public interface Test {
    public void parse();
    public Integer evaluate();
}
