package ast;

import libs.Node;

public abstract class STATEMENT extends Node {
}
